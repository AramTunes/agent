import { createFileRoute, Outlet, useRouterState } from "@tanstack/react-router";
import { PanelState, useAccount, useBusinessId } from "@/components/account";
import { DashboardHeader } from "@/components/dashboard-header";
import { Shell, Subnav } from "@/components/shell";
import { Skeleton } from "@/components/ui";
import { RedirectToSignIn } from "@/lib/auth/gates";

export const Route = createFileRoute("/panel")({ component: PanelLayout });

function PanelLayout() {
  const account = useAccount();
  const { businessId, choose } = useBusinessId(account.me?.memberships);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const home = pathname === "/panel" || pathname === "/panel/";
  const linksPage = pathname.startsWith("/panel/links");
  const header = (
    <DashboardHeader
      memberships={account.me?.memberships ?? []}
      businessId={businessId}
      onChoose={choose}
      onCreated={() => account.reload()}
    />
  );
  if (account.isPending || (account.user && account.loading && !account.me)) {
    return <Shell header={header}><Skeleton className="h-40" /></Shell>;
  }
  if (!account.user) return <RedirectToSignIn />;
  return (
    <Shell header={header}>
      {home || linksPage ? null : (
        <Subnav
          className="lg:hidden"
          items={[
            { to: "/panel", label: "خانه", exact: true },
            { to: "/panel/calendar", label: "تقویم" },
            { to: "/panel/services", label: "خدمات" },
            { to: "/panel/staff", label: "همکاران" },
            { to: "/panel/customers", label: "مشتریان" },
            { to: "/panel/settings", label: "تنظیمات" },
          ]}
        />
      )}
      <PanelState.Provider value={{
        businessId,
        memberships: account.me?.memberships ?? [],
        displayName: account.me?.profile.displayName ?? "",
        pageFor: account.me?.profile.pageFor ?? "",
        pageName: account.me?.profile.pageName ?? "",
      }}>
        <Outlet />
      </PanelState.Provider>
    </Shell>
  );
}