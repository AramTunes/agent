import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Briefcase,
  CalendarPlus,
  ChevronLeft,
  Copy,
  Ellipsis,
  File,
  FileText,
  GraduationCap,
  GripVertical,
  HelpCircle,
  Image as ImageIcon,
  ImagePlus,
  Link2,
  MapPin,
  Minus,
  Newspaper,
  Palette,
  Pencil,
  Phone,
  Plus,
  Settings,
  Share2,
  ShoppingBag,
  SlidersHorizontal,
  Star,
  Trash2,
  Type,
  User,
  Users,
  UtensilsCrossed,
  Video,
  X,
} from "lucide-react";
import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { toast } from "sonner";
import { usePanel } from "@/components/account";
import { ScrollArea } from "@/components/scroll-area";
import { Switch } from "@/components/switch";
import { Area, Button, Field, Skeleton, TextInput } from "@/components/ui";
import { manageBusinessFn, publicBusinessFn, updateBusinessFn } from "@/lib/api";
import { WEEKDAYS_FA, clockLabel, faNum, minutesLabel, toman } from "@/lib/booking/fa";
import { RoundAvatar, pageImageKey, readPageAvatar, readyAvatars, rememberPageAvatar } from "@/lib/page-avatar";

export const Route = createFileRoute("/panel/links")({ component: LinksPage });

const catalog = [
  { type: "link", label: "لینک", icon: Link2 },
  { type: "contact", label: "تماس", icon: Phone },
  { type: "address", label: "آدرس", icon: MapPin },
  { type: "booking", label: "رزرو نوبت", icon: CalendarPlus },
  { type: "products", label: "محصولات", icon: ShoppingBag },
  { type: "menu", label: "منوی دیجیتال", icon: UtensilsCrossed },
  { type: "services", label: "خدمات", icon: Briefcase },
  { type: "form", label: "فرم‌ساز", icon: FileText },
  { type: "event", label: "ایونت", icon: CalendarPlus },
  { type: "course", label: "دوره آموزشی", icon: GraduationCap },
  { type: "blog", label: "وبلاگ", icon: Newspaper },
  { type: "text", label: "متن ساده", icon: Type },
  { type: "social", label: "شبکه اجتماعی", icon: Share2 },
  { type: "faq", label: "سوالات متداول", icon: HelpCircle },
  { type: "team", label: "تیم", icon: Users },
  { type: "gallery", label: "گالری تصاویر", icon: ImageIcon },
  { type: "video", label: "ویدیو", icon: Video },
  { type: "resume", label: "رزومه", icon: FileText },
  { type: "file", label: "فایل", icon: File },
  { type: "divider", label: "جداکننده", icon: Minus },
] as const;

type BlockType = (typeof catalog)[number]["type"];
type Block = { id: string; type: BlockType; active: boolean; starred: boolean };
type Sheet = "" | "preview" | "settings" | "design";
type Design = { background: "paper" | "card" | "ink"; accent: "jade" | "copper" | "ink"; radius: "round" | "sharp" };
type Drag = { id: string; origin: number; over: number; slot: number; dy: number };
type Service = { id: string; name: string; description: string; durationMinutes: number; priceToman: number };
type Person = { id: string; name: string; title: string; weekly: { weekday: number; startMin: number; endMin: number }[] };
type Biz = {
  name: string;
  description: string;
  categoryName: string;
  city: string;
  address: string;
  phone: string;
  services: Service[];
  staff: Person[];
};

const defaultDesign: Design = { background: "paper", accent: "jade", radius: "round" };

function kindOf(type: BlockType) {
  return catalog.find((item) => item.type === type) ?? catalog[0];
}

function designKey(businessId: string) {
  return `nobat.page-design.${businessId}`;
}

function storageKey(businessId: string) {
  return `nobat.page-blocks.${businessId}`;
}

function reorder(items: Block[], fromId: string, toId: string) {
  const next = [...items];
  const from = next.findIndex((item) => item.id === fromId);
  const to = next.findIndex((item) => item.id === toId);
  if (from < 0 || to < 0 || from === to) return items;
  const [moved] = next.splice(from, 1);
  next.splice(to, 0, moved);
  return next;
}

function LinksPage() {
  const { businessId, memberships } = usePanel();
  const current = memberships.find((item) => item.businessId === businessId);
  const slug = current?.slug ?? "";
  const url = slug && typeof window !== "undefined" ? `${window.location.origin}/b/${slug}` : "";
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [ready, setReady] = useState(false);
  const [adding, setAdding] = useState(false);
  const [copied, setCopied] = useState(false);
  const [drag, setDrag] = useState<Drag | null>(null);
  const [menuId, setMenuId] = useState("");
  const [specialId, setSpecialId] = useState("");
  const listRef = useRef<HTMLUListElement>(null);
  const [sheet, setSheet] = useState<Sheet>("");
  const [qrOpen, setQrOpen] = useState(false);
  const [design, setDesign] = useState<Design>(defaultDesign);
  const [avatar, setAvatar] = useState("");

  useEffect(() => {
    if (!businessId) {
      setBlocks([]);
      setReady(false);
      return;
    }
    try {
      const raw = localStorage.getItem(storageKey(businessId));
      const parsed = raw ? (JSON.parse(raw) as Block[]) : [];
      setBlocks(Array.isArray(parsed) ? parsed : []);
    } catch {
      setBlocks([]);
    }
    setReady(true);
    try {
      const raw = localStorage.getItem(designKey(businessId));
      const parsed = raw ? (JSON.parse(raw) as Design) : defaultDesign;
      setDesign({ ...defaultDesign, ...parsed });
    } catch {
      setDesign(defaultDesign);
    }
  }, [businessId]);

  useEffect(() => {
    const value = readPageAvatar(businessId, slug);
    setAvatar(value);
    if (value) rememberPageAvatar(businessId, slug, value);
  }, [businessId, slug, sheet]);

  useEffect(() => {
    if (!ready || !businessId) return;
    localStorage.setItem(storageKey(businessId), JSON.stringify(blocks));
  }, [blocks, ready, businessId]);

  useEffect(() => {
    if (!menuId) return;
    const close = () => setMenuId("");
    window.addEventListener("click", close);
    return () => window.removeEventListener("click", close);
  }, [menuId]);

  useEffect(() => {
    const onAction = (event: Event) => {
      const action = (event as CustomEvent<string>).detail;
      if (action === "qr") setQrOpen(true);
      if (action === "preview" || action === "settings" || action === "design") setSheet(action);
    };
    window.addEventListener("nobat-links-action", onAction);
    return () => window.removeEventListener("nobat-links-action", onAction);
  }, []);

  function saveDesign(next: Design) {
    setDesign(next);
    if (businessId) localStorage.setItem(designKey(businessId), JSON.stringify(next));
  }

  function add(type: BlockType) {
    setBlocks((items) => [...items, { id: crypto.randomUUID(), type, active: true, starred: false }]);
    setAdding(false);
  }

  function update(id: string, patch: Partial<Block>) {
    setBlocks((items) => items.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  }

  function beginDrag(event: ReactPointerEvent<HTMLButtonElement>, id: string) {
    const row = event.currentTarget.closest("[data-block]") as HTMLElement | null;
    const list = listRef.current;
    if (!row || !list) return;
    event.preventDefault();
    event.stopPropagation();
    const pointerId = event.pointerId;
    event.currentTarget.setPointerCapture(pointerId);
    const rows = [...list.querySelectorAll<HTMLElement>("[data-block]")];
    const origin = rows.findIndex((item) => item.dataset.block === id);
    if (origin < 0) return;
    const rect = row.getBoundingClientRect();
    const centers = rows.map((item) => {
      const box = item.getBoundingClientRect();
      return box.top + box.height / 2;
    });
    const nextTop = rows[origin + 1]?.getBoundingClientRect().top;
    const slot = nextTop ? nextTop - rect.top : rect.height + 12;
    const startY = event.clientY;
    let over = origin;
    setDrag({ id, origin, over, slot, dy: 0 });
    const move = (ev: PointerEvent) => {
      if (ev.pointerId !== pointerId) return;
      ev.preventDefault();
      const dy = ev.clientY - startY;
      const y = centers[origin] + dy;
      let nextOver = 0;
      let best = Infinity;
      centers.forEach((center, index) => {
        const dist = Math.abs(center - y);
        if (dist < best) {
          best = dist;
          nextOver = index;
        }
      });
      over = nextOver;
      setDrag({ id, origin, over, slot, dy });
    };
    const end = (ev: PointerEvent) => {
      if (ev.pointerId !== pointerId) return;
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", end);
      window.removeEventListener("pointercancel", end);
      if (over !== origin) {
        const targetId = rows[over]?.dataset.block ?? "";
        if (targetId) setBlocks((items) => reorder(items, id, targetId));
      }
      setDrag(null);
    };
    window.addEventListener("pointermove", move, { passive: false });
    window.addEventListener("pointerup", end);
    window.addEventListener("pointercancel", end);
  }

  async function copyLink() {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="grid min-w-0 items-start gap-4 lg:grid-cols-[minmax(0,7fr)_minmax(0,3fr)]">
      <section className="min-w-0">
        <div className="flex items-center gap-2">
          <button type="button" className="inline-flex h-10 min-w-0 flex-1 items-center justify-center gap-2 rounded-full bg-ink px-3 text-sm font-medium text-on-ink" onClick={() => setAdding(true)}>
            <Plus className="size-4" aria-hidden="true" />
            افزودن بلوک
          </button>
          <button type="button" className="hidden h-10 shrink-0 items-center gap-2 rounded-full border border-line bg-paper px-3 text-sm font-medium lg:inline-flex" onClick={() => setSheet("settings")}>
            <Settings className="size-4" aria-hidden="true" />
            تنظیمات صفحه
          </button>
          <button type="button" className="hidden h-10 shrink-0 items-center gap-2 rounded-full border border-line bg-paper px-3 text-sm font-medium lg:inline-flex" onClick={() => setSheet("design")}>
            <Palette className="size-4" aria-hidden="true" />
            طراحی صفحه
          </button>
        </div>
        <ul ref={listRef} className="mt-4 grid gap-3 lg:gap-2">
          {blocks.length === 0 ? <li className="rounded-card border border-dashed border-line px-3 py-8 text-center text-sm text-muted">هنوز بلوکی به صفحه اضافه نشده.</li> : null}
          {blocks.map((block, index) => {
            const kind = kindOf(block.type);
            let shift = 0;
            if (drag && drag.id !== block.id) {
              if (drag.origin < drag.over && index > drag.origin && index <= drag.over) shift = -drag.slot;
              else if (drag.origin > drag.over && index >= drag.over && index < drag.origin) shift = drag.slot;
            }
            const held = drag?.id === block.id;
            const copyBlock = () => setBlocks((items) => {
              const at = items.findIndex((item) => item.id === block.id);
              if (at < 0) return items;
              const next = [...items];
              next.splice(at + 1, 0, { ...block, id: crypto.randomUUID(), starred: false });
              return next;
            });
            return (
              <li
                key={block.id}
                data-block={block.id}
                className=""
                style={
                  held
                    ? { transform: `translateY(${drag.dy}px)`, opacity: 0.45, zIndex: 30, position: "relative", transition: "none", boxShadow: "0 10px 24px rgb(0 0 0 / 0.14)" }
                    : {
                        transform: shift ? `translateY(${shift}px)` : undefined,
                        transition: shift ? "transform 180ms ease" : undefined,
                        position: "relative",
                        zIndex: menuId === block.id ? 40 : undefined,
                      }
                }
              >
                <div className="relative lg:hidden">
                <div className={`flex items-center gap-3 rounded-card border border-line bg-card p-4 ${block.active || held ? "" : "opacity-60"}`}>
                  <button
                    type="button"
                    aria-label="جابه‌جایی"
                    className="grid size-8 shrink-0 cursor-grab touch-none place-items-center text-muted select-none active:cursor-grabbing"
                    onPointerDown={(event) => beginDrag(event, block.id)}
                  >
                    <GripVertical className="size-4" aria-hidden="true" />
                  </button>
                  <kind.icon className="size-5 shrink-0 text-jade" aria-hidden="true" />
                  <span className="min-w-0 flex-1 truncate font-bold">{kind.label}</span>
                  <button
                    type="button"
                    aria-label="گزینه‌ها"
                    aria-expanded={menuId === block.id}
                    className="grid size-8 shrink-0 place-items-center rounded-full text-ink"
                    onClick={(event) => {
                      event.stopPropagation();
                      setMenuId((currentId) => (currentId === block.id ? "" : block.id));
                    }}
                  >
                    <Ellipsis className="size-5" aria-hidden="true" />
                  </button>
                </div>
                  {menuId === block.id ? (
                    <div className="absolute end-3 top-14 z-40 w-48 rounded-lg border border-line bg-card p-1 shadow-md" onClick={(event) => event.stopPropagation()}>
                      <div className="flex items-center justify-between gap-2 rounded-md px-2 py-1.5 text-sm">
                        <span>فعال</span>
                        <Switch checked={block.active} label={block.active ? "فعال" : "غیرفعال"} onCheckedChange={(active) => update(block.id, { active })} />
                      </div>
                      <button type="button" className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-start text-sm hover:bg-paper" onClick={() => { setMenuId(""); setSpecialId(block.id); }}>
                        <Star className={`size-4 ${block.starred ? "fill-current text-copper" : ""}`} aria-hidden="true" />
                        بلوک ویژه
                      </button>
                      <button type="button" className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-start text-sm hover:bg-paper" onClick={() => setMenuId("")}>
                        <Pencil className="size-4" aria-hidden="true" />
                        ویرایش
                      </button>
                      <button type="button" className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-start text-sm hover:bg-paper" onClick={() => { copyBlock(); setMenuId(""); }}>
                        <Copy className="size-4" aria-hidden="true" />
                        کپی
                      </button>
                      <button type="button" className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-start text-sm font-semibold text-[#e11d2e] hover:bg-danger-soft" onClick={() => { setBlocks((items) => items.filter((item) => item.id !== block.id)); setMenuId(""); }}>
                        <Trash2 className="size-4" aria-hidden="true" />
                        حذف
                      </button>
                    </div>
                  ) : null}
                </div>
                <div className={`hidden items-center gap-2 rounded-lg border border-line bg-card px-2 py-2 lg:flex ${block.active ? "" : "opacity-60"}`}>
                  <button
                    type="button"
                    aria-label="جابه‌جایی"
                    className="grid size-8 shrink-0 cursor-grab touch-none place-items-center rounded-full text-muted select-none active:cursor-grabbing"
                    onPointerDown={(event) => beginDrag(event, block.id)}
                  >
                    <GripVertical className="size-4" aria-hidden="true" />
                  </button>
                  <kind.icon className="size-4 shrink-0" aria-hidden="true" />
                  <span className="min-w-0 flex-1 truncate text-sm font-medium">{kind.label}</span>
                  <button
                    type="button"
                    aria-label={block.starred ? "برداشتن ستاره" : "ستاره"}
                    aria-pressed={block.starred}
                    className={`grid size-8 place-items-center rounded-full ${block.starred ? "text-copper" : "text-muted"}`}
                    onClick={() => update(block.id, { starred: !block.starred })}
                  >
                    <Star className={`size-4 ${block.starred ? "fill-current" : ""}`} aria-hidden="true" />
                  </button>
                  <Switch checked={block.active} label={block.active ? "فعال" : "غیرفعال"} onCheckedChange={(active) => update(block.id, { active })} />
                  <button type="button" aria-label="ویرایش" className="grid size-8 place-items-center rounded-full text-muted hover:bg-paper hover:text-ink">
                    <Pencil className="size-4" aria-hidden="true" />
                  </button>
                  <button type="button" aria-label="کپی" className="grid size-8 place-items-center rounded-full text-muted hover:bg-paper hover:text-ink" onClick={copyBlock}>
                    <Copy className="size-4" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    aria-label="حذف"
                    className="grid size-8 place-items-center rounded-full text-danger hover:bg-danger-soft"
                    onClick={() => setBlocks((items) => items.filter((item) => item.id !== block.id))}
                  >
                    <Trash2 className="size-4" aria-hidden="true" />
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      </section>
      <aside className="hidden min-w-0 lg:grid lg:gap-3">
        <button type="button" onClick={() => void copyLink()} title={url || undefined} className="w-full min-w-0 overflow-hidden rounded-xl border border-line bg-card p-3 text-start">
          <span className="flex items-center gap-2 text-sm font-semibold">
            <Share2 className="size-4 shrink-0" aria-hidden="true" />
            {copied ? "کپی شد" : "اشتراک‌گذاری"}
          </span>
          <span className="mt-2 block w-full break-all text-xs leading-5 text-muted" dir="ltr">{url || "نشانی صفحه هنوز آماده نیست"}</span>
        </button>
        <div className="rounded-[1.7rem] border-4 border-ink bg-ink p-1.5">
          <div className="overflow-hidden rounded-[1.3rem] bg-paper">
            <div className="mx-auto mt-2 h-1.5 w-14 rounded-full bg-ink/80" />
            <PhoneScreen slug={slug} blocks={blocks} design={design} image={avatar} />
          </div>
        </div>
      </aside>
      {adding ? <BlockPicker onClose={() => setAdding(false)} onPick={add} /> : null}
      {sheet === "preview" ? (
        <HalfSheet title="پیش‌نمایش" onClose={() => setSheet("")}>
          <div className="mx-auto h-full max-w-[16rem] rounded-[1.5rem] border-4 border-ink bg-ink p-1.5">
            <div className="flex h-full flex-col overflow-hidden rounded-[1.15rem] bg-paper">
              <div className="mx-auto mt-2 h-1.5 w-14 shrink-0 rounded-full bg-ink/80" />
              <PhoneScreen slug={slug} blocks={blocks} design={design} image={avatar} className="min-h-0 flex-1" />
            </div>
          </div>
        </HalfSheet>
      ) : null}
      {sheet === "settings" ? (
        <HalfSheet title="تنظیمات صفحه" onClose={() => setSheet("")}>
          <PageSettings businessId={businessId} slug={slug} onClose={() => setSheet("")} />
        </HalfSheet>
      ) : null}
      {sheet === "design" ? (
        <HalfSheet title="طراحی صفحه" onClose={() => setSheet("")}>
          <DesignSettings design={design} onChange={saveDesign} />
        </HalfSheet>
      ) : null}
      {qrOpen && current ? <QrDialog name={current.name} slug={slug} url={url} onClose={() => setQrOpen(false)} /> : null}
      {specialId ? <SpecialBlockDialog onClose={() => setSpecialId("")} /> : null}
    </div>
  );
}

function SpecialBlockDialog({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4">
      <button type="button" className="absolute inset-0 bg-black/40" aria-label="بستن" onClick={onClose} />
      <div className="relative z-10 w-full max-w-sm rounded-card border border-line bg-card p-5 shadow-xl">
        <h2 className="font-extrabold">بلوک ویژه</h2>
        <div className="mt-4 flex justify-end">
          <Button type="button" variant="quiet" onClick={onClose}>بستن</Button>
        </div>
      </div>
    </div>
  );
}

function PhoneScreen({ slug, blocks, design = defaultDesign, image = "", className = "h-[34rem]" }: { slug: string; blocks: Block[]; design?: Design; image?: string; className?: string }) {
  const [biz, setBiz] = useState<Biz | null>(null);
  useEffect(() => {
    if (!slug) return;
    let live = true;
    publicBusinessFn({ data: { slug, track: false } }).then((res) => {
      if (live && res.ok) setBiz(res.data as Biz);
    });
    return () => {
      live = false;
    };
  }, [slug]);
  const shown = blocks.filter((item) => item.active);
  const canvas = design.background === "ink" ? "bg-ink text-on-ink" : design.background === "card" ? "bg-card" : "bg-paper";
  return (
    <ScrollArea className={`${className} ${canvas}`}>
      {!slug || !biz ? <p className="px-3 py-10 text-center text-xs text-muted">صفحه هنوز برای مشتری چیده نشده.</p> : (
        <div className="grid gap-3 p-3">
          <div className="grid justify-items-center text-center">
            {image ? <RoundAvatar value={image} size={72} /> : <span className="grid size-[72px] place-items-center rounded-full bg-jade text-lg font-bold text-on-jade">{biz.name.trim().slice(0, 1) || "ن"}</span>}
            <h3 className="mt-2 text-base font-extrabold">{biz.name}</h3>
            {biz.categoryName ? <p className="mt-1 text-xs text-muted">{biz.categoryName}</p> : null}
            {biz.description ? <p className="mt-2 text-xs leading-5 text-muted">{biz.description}</p> : null}
          </div>
          {shown.length === 0 ? <CustomerPage biz={biz} design={design} /> : shown.map((block) => <CustomerBlock key={block.id} block={block} biz={biz} design={design} />)}
        </div>
      )}
    </ScrollArea>
  );
}

function buttonLook(design: Design) {
  const color = design.accent === "copper" ? "bg-copper text-on-ink" : design.accent === "ink" ? "bg-ink text-on-ink" : "bg-jade text-on-jade";
  const radius = design.radius === "sharp" ? "rounded-sm" : "rounded-lg";
  return `inline-flex h-10 items-center justify-center text-sm font-semibold ${color} ${radius}`;
}

function CustomerPage({ biz, design }: { biz: Biz; design: Design }) {
  return (
    <>
      <CustomerFacts biz={biz} />
      <span className={buttonLook(design)}>رزرو نوبت</span>
      {biz.services.map((service) => <ServiceCard key={service.id} service={service} />)}
      <StaffCard biz={biz} />
    </>
  );
}

function CustomerBlock({ block, biz, design }: { block: Block; biz: Biz; design: Design }) {
  if (block.type === "divider") return <div className="h-px bg-line" />;
  if (block.type === "booking") return <span className={buttonLook(design)}>رزرو نوبت</span>;
  if (block.type === "contact" || block.type === "address") return <CustomerFacts biz={biz} only={block.type} />;
  if (block.type === "text") return biz.description ? <p className="text-xs leading-5 text-muted">{biz.description}</p> : null;
  if (block.type === "services") return <>{biz.services.map((service) => <ServiceCard key={service.id} service={service} />)}</>;
  if (block.type === "team") return <StaffCard biz={biz} />;
  const kind = kindOf(block.type);
  return (
    <div className="flex items-center gap-2 rounded-lg border border-line bg-card px-3 py-2.5 text-sm">
      <kind.icon className="size-4 shrink-0" aria-hidden="true" />
      <span>{kind.label}</span>
    </div>
  );
}

function CustomerFacts({ biz, only }: { biz: Biz; only?: "contact" | "address" }) {
  const place = [biz.city, biz.address].filter(Boolean).join(" ");
  return (
    <div className="grid gap-1 text-xs text-muted">
      {only !== "contact" && place ? <span className="inline-flex items-center gap-1"><MapPin className="size-3.5" />{place}</span> : null}
      {only !== "address" && biz.phone ? <span className="inline-flex items-center gap-1"><Phone className="size-3.5" />{faNum(biz.phone)}</span> : null}
    </div>
  );
}

function ServiceCard({ service }: { service: Service }) {
  return (
    <div className="rounded-lg border border-line bg-card px-3 py-2">
      <div className="flex items-start justify-between gap-2">
        <span className="text-sm font-semibold">{service.name}</span>
        <span className="text-xs tabular-nums">{toman(service.priceToman)}</span>
      </div>
      <p className="mt-1 text-xs text-muted">{minutesLabel(service.durationMinutes)}</p>
    </div>
  );
}

function StaffCard({ biz }: { biz: Biz }) {
  return (
    <div className="rounded-lg border border-line bg-card px-3 py-2">
      {biz.staff.map((person) => (
        <div key={person.id} className="mt-2 first:mt-0">
          <div className="text-sm font-semibold">{person.name}</div>
          <div className="text-xs text-muted">{person.title}</div>
          <ul className="mt-1 grid gap-0.5 text-xs">
            {person.weekly.map((row) => (
              <li key={row.weekday} className="flex justify-between gap-2">
                <span>{WEEKDAYS_FA[row.weekday]}</span>
                <span className="tabular-nums">{clockLabel(row.startMin)} تا {clockLabel(row.endMin)}</span>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}

function HalfSheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const heights = ["42dvh", "68dvh", "calc(100dvh - 4rem)"];
  const [level, setLevel] = useState(1);
  const [leaving, setLeaving] = useState(false);
  function close() {
    setLeaving(true);
  }
  function resizeFrom(event: ReactPointerEvent<HTMLButtonElement>) {
    const startY = event.clientY;
    const start = level;
    const pointerId = event.pointerId;
    event.currentTarget.setPointerCapture(pointerId);
    const end = (ev: PointerEvent) => {
      if (ev.pointerId !== pointerId) return;
      const dy = startY - ev.clientY;
      const steps = Math.abs(dy) > 140 ? Math.sign(dy) * 2 : Math.abs(dy) > 28 ? Math.sign(dy) : 0;
      setLevel(Math.min(2, Math.max(0, start + steps)));
      window.removeEventListener("pointerup", end);
      window.removeEventListener("pointercancel", end);
    };
    window.addEventListener("pointerup", end);
    window.addEventListener("pointercancel", end);
  }
  return (
    <div className="fixed inset-0 z-50">
      <button type="button" className="absolute inset-0 bg-black/40" aria-label="بستن" onClick={close} />
      <div
        className={`absolute inset-x-0 bottom-0 flex flex-col rounded-t-2xl border border-line bg-card shadow-xl transition-[height] duration-200 ${leaving ? "sheet-down" : "sheet-up"}`}
        style={{ height: heights[level] }}
        onAnimationEnd={() => {
          if (leaving) onClose();
        }}
      >
        <div className="relative flex items-center justify-between px-4 pt-2 pb-5">
          <h2 className="font-bold">{title}</h2>
          <button type="button" aria-label="اندازه صفحه" onPointerDown={resizeFrom} className="absolute left-1/2 top-1 -translate-x-1/2 px-8 py-2 touch-none">
            <span className="block h-1.5 w-10 rounded-full bg-muted/50" />
          </button>
          <button type="button" aria-label="بستن" onClick={close} className="grid size-9 place-items-center text-ink">
            <X className="size-5" aria-hidden="true" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-6">{children}</div>
      </div>
    </div>
  );
}

function imageKey(businessId: string) {
  return pageImageKey(businessId);
}

function readGalleryImage(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read"));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("image"));
      img.onload = () => {
        const max = 640;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("canvas"));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

function PageSettings({ businessId, slug, onClose }: { businessId: string; slug: string; onClose: () => void }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [imageOpen, setImageOpen] = useState(false);
  const [form, setForm] = useState<{ name: string; description: string; city: string; phone: string; address: string; categoryId: string; timezone: string; cancelBeforeMinutes: number; minLeadMinutes: number; maxHorizonDays: number; slotStepMinutes: number; allowAnyStaff: boolean } | null>(null);
  const [image, setImage] = useState("");
  const [pending, setPending] = useState(false);
  useEffect(() => {
    if (!businessId) return;
    try {
      setImage(localStorage.getItem(imageKey(businessId)) ?? "");
    } catch {
      setImage("");
    }
    manageBusinessFn({ data: { businessId } }).then((res) => {
      if (!res.ok) return;
      const data = res.data;
      setForm({
        name: data.name ?? "",
        description: String(data.description ?? "").slice(0, 100),
        city: data.city ?? "",
        phone: data.phone ?? "",
        address: data.address ?? "",
        categoryId: data.categoryId ?? "",
        timezone: data.timezone ?? "Asia/Tehran",
        cancelBeforeMinutes: data.cancelBeforeMinutes ?? 0,
        minLeadMinutes: data.minLeadMinutes ?? 0,
        maxHorizonDays: data.maxHorizonDays ?? 30,
        slotStepMinutes: data.slotStepMinutes ?? 15,
        allowAnyStaff: Boolean(data.allowAnyStaff),
      });
    });
  }, [businessId]);
  if (!form) return <Skeleton className="h-40" />;
  return (
    <form
      className="grid"
      onSubmit={(event) => {
        event.preventDefault();
        setPending(true);
        try {
          if (image) rememberPageAvatar(businessId, slug, image);
          else {
            localStorage.removeItem(pageImageKey(businessId));
            if (slug) localStorage.removeItem(`nobat.page-image.slug.${slug}`);
          }
        } catch {
          toast.error("تصویر ذخیره نشد");
        }
        void updateBusinessFn({ data: { businessId, ...form, description: form.description.slice(0, 100) } }).then((res) => {
          setPending(false);
          if (!res.ok) {
            toast.error(res.error);
            return;
          }
          toast.success("تنظیمات صفحه ذخیره شد");
          onClose();
        });
      }}
    >
      <div className="grid justify-items-center">
        <span className="grid size-24 place-items-center overflow-hidden rounded-full bg-jade-soft text-jade">
          {image ? <RoundAvatar value={image} size={96} /> : <User className="size-10" aria-hidden="true" />}
        </span>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (!file) return;
            void readGalleryImage(file).then(setImage).catch(() => toast.error("این تصویر باز نشد"));
          }}
        />
        <button type="button" className="mt-3 inline-flex h-10 items-center gap-2 rounded-full border border-line bg-paper px-4 text-sm font-medium" onClick={() => setImageOpen(true)}>
          <ImagePlus className="size-4" aria-hidden="true" />
          تغییر تصویر
        </button>
        {imageOpen ? (
          <ImageDialog
            image={image}
            onPick={setImage}
            onUpload={() => fileRef.current?.click()}
            onClose={() => setImageOpen(false)}
          />
        ) : null}
      </div>
      <div className="mt-5">
        <Field label="نام صفحه">
          <TextInput value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        </Field>
      </div>
      <div className="mt-3">
        <label className="grid gap-1.5 text-sm">
          <span className="flex items-center justify-between gap-3">
            <span className="font-medium">بیو</span>
            <span className="text-xs tabular-nums text-muted">{faNum(form.description.length)}/{faNum(100)}</span>
          </span>
          <Area
            value={form.description}
            maxLength={100}
            onChange={(e) => setForm({ ...form, description: e.target.value.slice(0, 100) })}
          />
        </label>
      </div>
      <Link to="/panel/settings" className="mt-4 flex items-center gap-2.5 rounded-xl border border-line bg-paper px-3 py-2.5">
        <SlidersHorizontal className="size-4 shrink-0 text-jade" aria-hidden="true" />
        <span className="min-w-0 flex-1">
          <span className="block text-sm font-bold">تنظیمات کامل صفحه</span>
          <span className="mt-0.5 block text-xs leading-5 text-muted">آدرس، دیده شدن در گوگل، اشتراک گذاری و اشتراک</span>
        </span>
        <ChevronLeft className="size-4 shrink-0 text-muted" aria-hidden="true" />
      </Link>
      <div className="mt-8 flex gap-2">
        <button type="submit" disabled={pending} className="inline-flex h-11 min-w-0 flex-1 items-center justify-center rounded-full bg-ink text-sm font-semibold text-on-ink disabled:opacity-50">
          {pending ? "در حال ذخیره" : "ذخیره"}
        </button>
        <button type="button" className="inline-flex h-11 min-w-0 flex-1 items-center justify-center rounded-full border border-line bg-paper text-sm font-semibold text-ink" onClick={onClose}>
          انصراف
        </button>
      </div>
    </form>
  );
}

function ImageDialog({ image, onPick, onUpload, onClose }: { image: string; onPick: (next: string) => void; onUpload: () => void; onClose: () => void }) {
  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="page-image-title"
        className="grid max-h-[85dvh] w-full max-w-sm gap-4 overflow-y-auto rounded-[1.375rem] border border-line bg-card p-5 text-ink shadow-[0_20px_50px_-20px_rgb(0_0_0/0.8)]"
      >
        <h2 id="page-image-title" className="text-base font-semibold">تصویر صفحه</h2>
        <span className="mx-auto grid size-24 place-items-center overflow-hidden rounded-full bg-jade-soft text-jade">
          {image ? <RoundAvatar value={image} size={96} /> : <User className="size-10" aria-hidden="true" />}
        </span>
        <button type="button" className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-ink text-sm font-semibold text-on-ink" onClick={onUpload}>
          <ImagePlus className="size-4" aria-hidden="true" />
          تغییر تصویر
        </button>
        <div>
          <p className="text-sm font-semibold">آواتارهای آماده</p>
          <ScrollArea className="mt-3 max-h-48">
            <div className="grid grid-cols-5 gap-2 pe-1">
              {readyAvatars.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-label="آواتار آماده"
                  className={`grid size-12 place-items-center overflow-hidden rounded-full ${image === item.id ? "ring-2 ring-jade ring-offset-2 ring-offset-card" : ""}`}
                  onClick={() => onPick(item.id)}
                >
                  <RoundAvatar value={item.id} size={48} />
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>
        <button type="button" className="text-sm font-semibold text-[#e11d2e]" onClick={() => onPick(readyAvatars[0].id)}>
          حذف تصویر آپلود شده
        </button>
        <button type="button" className="inline-flex h-11 items-center justify-center rounded-full border border-line bg-paper text-sm font-semibold text-ink" onClick={onClose}>
          بستن
        </button>
      </div>
    </div>,
    document.body,
  );
}

function DesignSettings({ design, onChange }: { design: Design; onChange: (next: Design) => void }) {
  return (
    <div className="grid gap-4">
      <Choice label="پس‌زمینه" value={design.background} options={[["paper", "کاغذی"], ["card", "سفید"], ["ink", "تیره"]]} onChange={(background) => onChange({ ...design, background: background as Design["background"] })} />
      <Choice label="رنگ دکمه" value={design.accent} options={[["jade", "سبز"], ["copper", "مسی"], ["ink", "مشکی"]]} onChange={(accent) => onChange({ ...design, accent: accent as Design["accent"] })} />
      <Choice label="گوشه‌ها" value={design.radius} options={[["round", "گرد"], ["sharp", "تیز"]]} onChange={(radius) => onChange({ ...design, radius: radius as Design["radius"] })} />
    </div>
  );
}

function Choice({ label, value, options, onChange }: { label: string; value: string; options: string[][]; onChange: (value: string) => void }) {
  return (
    <div>
      <p className="mb-2 text-sm font-semibold">{label}</p>
      <div className="flex flex-wrap gap-2">
        {options.map(([id, text]) => (
          <button key={id} type="button" className={`h-9 rounded-full border px-3 text-sm ${value === id ? "border-ink bg-ink text-on-ink" : "border-line bg-paper"}`} onClick={() => onChange(id)}>
            {text}
          </button>
        ))}
      </div>
    </div>
  );
}

function QrDialog({ name, slug, url, onClose }: { name: string; slug: string; url: string; onClose: () => void }) {
  const [src, setSrc] = useState("");
  const link = url || `/b/${slug}`;
  useEffect(() => {
    let live = true;
    const target = url || `${window.location.origin}/b/${slug}`;
    import("qrcode").then((QR) => QR.toDataURL(target, { width: 320, margin: 1, color: { dark: "#121212", light: "#ffffff" } })).then((next) => {
      if (live) setSrc(next);
    });
    return () => {
      live = false;
    };
  }, [slug, url]);
  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4">
      <button type="button" className="absolute inset-0 bg-black/40" aria-label="بستن" onClick={onClose} />
      <div className="relative z-10 grid w-full max-w-sm justify-items-center gap-3 rounded-card border border-line bg-card p-5 text-center shadow-xl">
        <h2 className="font-extrabold">{name}</h2>
        {src ? <img src={src} alt="" className="size-56 rounded-xl bg-white p-2" /> : <Skeleton className="size-56" />}
        <p className="w-full break-all text-sm text-muted" dir="ltr">{link}</p>
        <Button
          type="button"
          variant="signup"
          onClick={() => {
            const target = url || `${window.location.origin}/b/${slug}`;
            void navigator.clipboard.writeText(target).then(() => toast.success("لینک کپی شد")).catch(() => toast.error("کپی نشد"));
          }}
        >
          کپی لینک
        </Button>
      </div>
    </div>
  );
}

function BlockPicker({ onClose, onPick }: { onClose: () => void; onPick: (type: BlockType) => void }) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-ink/40 p-4" onClick={onClose}>
      <div className="grid max-h-[80vh] w-full max-w-2xl grid-rows-[auto_minmax(0,1fr)] rounded-card border border-line bg-paper p-4 shadow-md" onClick={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-labelledby="add-block-title">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 id="add-block-title" className="text-base font-bold">افزودن بلوک</h2>
          <button type="button" className="text-sm text-muted" onClick={onClose}>بستن</button>
        </div>
        <ScrollArea className="max-h-[60vh] pe-1">
          <div className="grid grid-cols-2 gap-3">
            {catalog.map((item) => (
              <button key={item.type} type="button" className="flex min-h-24 flex-col justify-between rounded-card border border-line bg-card p-4 text-start" onClick={() => onPick(item.type)}>
                <item.icon className="size-5 text-jade" aria-hidden="true" />
                <span className="font-bold">{item.label}</span>
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
