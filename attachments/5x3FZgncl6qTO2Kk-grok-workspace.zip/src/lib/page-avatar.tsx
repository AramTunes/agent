import { useEffect, useState } from "react";
import Avatar from "boring-avatars";

const seeds = [
  "aria", "mina", "reza", "sara", "kian", "nilo", "omid", "lida", "arman", "homa",
  "yas", "pari", "sina", "roya", "nima", "dara", "elham", "farid", "gita", "hamed",
  "iman", "jaleh", "kamran", "leila", "mahsa", "nader", "ozra", "pouya", "ramin", "shadi",
  "tara", "vahid", "yegane", "zahra", "baran", "caspian",
];

export const avatarColors = ["#92A1C6", "#146A7C", "#F0AB3D", "#C271B4", "#C20D90"];
export const readyAvatars = seeds.map((name) => ({ variant: "beam" as const, name, id: `beam:${name}` }));

export function pageImageKey(businessId: string) {
  return `nobat.page-image.${businessId}`;
}

export function pageImageSlugKey(slug: string) {
  return `nobat.page-image.slug.${slug}`;
}

export function assignRandomPageAvatar(businessId: string) {
  const pick = readyAvatars[Math.floor(Math.random() * readyAvatars.length)];
  try {
    localStorage.setItem(pageImageKey(businessId), pick.id);
  } catch {
    /* storage can be full or blocked */
  }
  return pick.id;
}

export function rememberPageAvatar(businessId: string, slug: string, value: string) {
  try {
    if (businessId) localStorage.setItem(pageImageKey(businessId), value);
    if (slug) localStorage.setItem(pageImageSlugKey(slug), value);
  } catch {
    /* ignore */
  }
}

export function readPageAvatar(businessId?: string, slug?: string) {
  if (typeof window === "undefined") return "";
  try {
    if (businessId) return localStorage.getItem(pageImageKey(businessId)) ?? "";
    if (slug) return localStorage.getItem(pageImageSlugKey(slug)) ?? "";
  } catch {
    return "";
  }
  return "";
}

export function RoundAvatar({ value, size = 40 }: { value: string; size?: number }) {
  const beamName = value.startsWith("beam:") ? value.slice(5) : value.includes(":") ? value.slice(value.indexOf(":") + 1) : "";
  const photo = value.startsWith("data:") || value.startsWith("blob:") || value.startsWith("http");
  return (
    <span className="grid shrink-0 overflow-hidden rounded-full [&>svg]:block [&>svg]:size-full" style={{ width: size, height: size }}>
      {photo ? <img src={value} alt="" className="size-full rounded-full object-cover" /> : beamName ? <Avatar size={size} name={beamName} variant="beam" colors={avatarColors} /> : null}
    </span>
  );
}

export function PageMark({ businessId, slug, name, size = 32 }: { businessId?: string; slug?: string; name: string; size?: number }) {
  const [image, setImage] = useState("");
  useEffect(() => {
    setImage(readPageAvatar(businessId, slug));
  }, [businessId, slug]);
  if (image) return <RoundAvatar value={image} size={size} />;
  const letter = name.trim().slice(0, 1) || "ن";
  return (
    <span className="grid shrink-0 place-items-center rounded-full bg-jade text-xs font-bold text-on-jade" style={{ width: size, height: size }}>
      {letter}
    </span>
  );
}
