import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CustomerLinkStage, type CustomerBlock } from "@/components/link-page";
import { publicBusinessFn } from "@/lib/api";

export const Route = createFileRoute("/b/$slug/")({ component: BusinessPage });

type Biz = {
  name: string;
  description: string;
  avatar?: string;
  pageBlocks?: CustomerBlock[];
};

function BusinessPage() {
  const { slug } = Route.useParams();
  const [biz, setBiz] = useState<Biz | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    let live = true;
    publicBusinessFn({ data: { slug, track: true } }).then((res) => {
      if (!live) return;
      if (res.ok) setBiz(res.data);
      else setError(res.error);
    });
    return () => {
      live = false;
    };
  }, [slug]);
  if (error) {
    return (
      <CustomerLinkStage name="نوبتک" bio={error} slug={slug} blocks={[]} />
    );
  }
  if (!biz) {
    return <div className="min-h-dvh bg-black" />;
  }
  const blocks = Array.isArray(biz.pageBlocks) ? biz.pageBlocks : [];
  return <CustomerLinkStage name={biz.name} bio={biz.description ?? ""} avatar={biz.avatar} slug={slug} blocks={blocks} />;
}
