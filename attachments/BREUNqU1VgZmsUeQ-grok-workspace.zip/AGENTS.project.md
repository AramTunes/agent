# نوبتک — project contract

Continue this product. Do not restyle it into a generic template, and do not replace the Go booking API with TanStack server functions or Postgres unless the user explicitly asks.

## Product

Persian (RTL) appointment product named **نوبتک**. Public site lets people find a business and book a real free slot. Owners run a dashboard: page builder, services, staff, calendar, customers, reports. Platform admin lives under `/admin`.

## Stack (keep)

- UI: TanStack Start + React 19 + Tailwind v4. Font Vazirmatn. Tokens in `src/styles.css`.
- Booking API: Go module `nobatak` in `api/`. SQLite file `data/nobat.db` (`modernc.org/sqlite`, WAL). Process listens on unix socket `NOBAT_SOCK` (default `/workspace/data/nobat.sock`, not `/tmp`, so the preview server and the API see the same file).
- Vite plugin `nobatApiPlugin` in `vite.config.ts` proxies `/api/v1` to that socket. The browser only talks to the preview origin.
- `startup.sh` starts the Go binary, then `npm run dev` on `0.0.0.0:8080`.
- Product auth is phone + password / OTP in the Go API. Token is `localStorage` key `nobat.token`. Do not swap this for the platform Better Auth flow.
- Grok gate/auth shell (`AuthProvider`, `PreviewHostBridge`, PWA injector) stays mounted and is not the product login.

## Design

- `html lang="fa" dir="rtl"`.
- Public surfaces: paper `#f7f7f5`, ink `#121212`, jade `#0e6b54`, copper accent. Cards `rounded-card`, hairline borders, light/dark via `data-theme` and `nobat.theme`.
- Signed-in app chrome: desktop sidebar in `desktop-nav.tsx`, mobile drawer. Dashboard home uses the scoped `.graphite` theme (near-black, white primary button, amber accent). Do not paint the public site graphite.
- Numbers shown to people go through `src/lib/booking/fa.ts`. Dates in the UI are Jalali (`jalaali-js`, `jalali-calendar.tsx`). Instants in the API are UTC ISO.
- New UI follows [وایب‌فارسی](https://vibefarsi.ir/components). If the user names a component, use that one. If they do not, look up the closest match on that site and adapt it to نوبتک tokens (do not import a second design system). RTL, Persian copy, Vazirmatn.
- Link-page block `resume` is parked: hidden from the add picker, the editor list, and the public page. Leave its saved data and form schema in place so it can return later. Do not delete the type.

## Booking rules (do not weaken)

- Slot math is pure and lives in `api/internal/booking`. Timezone default `Asia/Tehran`. A slot is duration + buffer, stepped, clipped by working hours, breaks, holidays, existing busy intervals, min lead, and horizon.
- `CreateBooking` rechecks the slot inside a transaction, rejects overlaps on `(staff, pending|confirmed)` against `[start, buffer_until)`, and is idempotent via `idempotency_key`.
- Status machine: pending → confirmed|cancelled; confirmed → completed|cancelled|no_show.
- API envelope is always `{ ok, data }` or `{ ok:false, error, code }`. Client wrappers stay in `src/lib/api.ts`.

## When changing code

- UI copy stays Persian. Match existing components (`ui.tsx`, `shell.tsx`, `account.tsx`) instead of introducing a second visual system.
- Schema changes belong in `api/internal/app/db.go` as idempotent `CREATE/ALTER` that tolerate the existing `data/nobat.db`.
- Rebuild `api/bin/nobat-api` from `api/cmd/server` when Go code changes, then restart only the API process. Do not point the UI at a second public port.
